create function "overlaps"(timestamp without time zone, interval, timestamp without time zone, timestamp without time zone) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
RETURN (($1, ($1 + $2)) OVERLAPS ($3, $4));

comment on function "overlaps"(timestamp, interval, timestamp, timestamp) is 'intervals overlap?';

alter function "overlaps"(timestamp, interval, timestamp, timestamp) owner to postgres;

