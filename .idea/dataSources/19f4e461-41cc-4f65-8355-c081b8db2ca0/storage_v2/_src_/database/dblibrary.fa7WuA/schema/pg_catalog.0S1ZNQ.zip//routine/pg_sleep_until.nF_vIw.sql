create function pg_sleep_until(timestamp with time zone) returns void
    strict
    parallel safe
    cost 1
    language sql
RETURN pg_sleep(((EXTRACT(epoch FROM $1) - EXTRACT(epoch FROM clock_timestamp())))::double precision);

comment on function pg_sleep_until(timestamp with time zone) is 'sleep until the specified time';

alter function pg_sleep_until(timestamp with time zone) owner to postgres;

