create view view_文学图书基本信息 (bookid, booktitle, isbn, typeid, author, press, pudate, price, regdate, state) as
SELECT bookid,
       booktitle,
       isbn,
       typeid,
       author,
       press,
       pudate,
       price,
       regdate,
       state
FROM book
WHERE (typeid IN (SELECT booktype.typeid
                  FROM booktype
                  WHERE booktype.typename::text = '文学'::text));

alter table view_文学图书基本信息
    owner to postgres;

