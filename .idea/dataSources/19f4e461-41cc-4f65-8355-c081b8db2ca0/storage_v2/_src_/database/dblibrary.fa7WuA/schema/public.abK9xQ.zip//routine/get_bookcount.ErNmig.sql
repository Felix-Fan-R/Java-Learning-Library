create procedure get_bookcount(IN reader_id character, OUT book_count integer)
    language plpgsql
as
$$
BEGIN
    SELECT COUNT(*)
    INTO book_count
    FROM Record
    WHERE Readerid = reader_id;
END;
$$;

alter procedure get_bookcount(char, out integer) owner to postgres;

