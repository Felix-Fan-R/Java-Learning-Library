create function get_employees_by_departmentss(department_id integer) returns SETOF character varying
    language plpgsql
as
$$
  
BEGIN  
    RETURN QUERY SELECT "姓名" FROM "员工" WHERE "部门ID" = department_id;  
END  
 
$$;

alter function get_employees_by_departmentss(integer) owner to postgres;

