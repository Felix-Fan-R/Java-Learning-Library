create function insert_student_with_check(name1 character varying, age1 integer) returns void
    language plpgsql
as
$$
DECLARE   
    new_student_id INTEGER;   
BEGIN   
	insert into students(name,age)VALUES(name1,age1) RETURNING id into new_student_id;
	IF new_student_id IS NULL THEN
		RAISE EXCEPTION 'Failed to insert student:No ID was returned.';
	END IF;
	IF age1<18 THEN
		BEGIN
			INSERT INTO underage_students(student_id) VALUES(new_student_id);  
        EXCEPTION    
            WHEN unique_violation THEN    
                RAISE NOTICE 'Student with ID % already exists in underage_students table.', new_student_id;  
                -- 可以在这里添加其他逻辑，如记录日志等  
            WHEN OTHERS THEN  
                -- 捕获其他可能发生的异常  
                RAISE EXCEPTION 'An unexpected error occurred while inserting the student with ID %.', new_student_id;  
        END;    
    END IF;   
    -- 通常不需要在这里显式提交事务，因为函数结束时如果没有异常则会自动提交  
	--commit;
EXCEPTION   
    WHEN OTHERS THEN   
        -- 如果发生异常，回滚事务  
        RAISE EXCEPTION 'An error occurred while inserting the student: %', SQLERRM; -- 使用SQLERRM获取错误消息  
        ROLLBACK; -- 注意：通常这里的ROLLBACK是多余的，因为异常会自动导致回滚  
END;   
$$;

alter function insert_student_with_check(varchar, integer) owner to postgres;

