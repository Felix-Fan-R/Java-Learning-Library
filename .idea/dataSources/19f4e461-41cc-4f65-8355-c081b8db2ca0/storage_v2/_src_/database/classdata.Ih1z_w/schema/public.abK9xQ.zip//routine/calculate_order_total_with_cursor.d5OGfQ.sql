create function calculate_order_total_with_cursor(order_id_param integer) returns numeric
    language plpgsql
as
$$
DECLARE
	total_price DECIMAL(10,2) := 0;
	product_price DECIMAL(10,2);
	quantity INT;
	cursor_order_items CURSOR FOR
		SELECT oi.quantity,p.price
		FROM order_items oi
		JOIN products p ON oi.product_id=p.product_id
		WHERE oi.order_id = order_id_param;
BEGIN
	OPEN cursor_order_items;
	LOOP 
		FETCH cursor_order_items INTO quantity,product_price;
		EXIT WHEN NOT FOUND;
		total_price := total_price + (quantity*product_price);
	END LOOP;
	CLOSE cursor_order_items;
	RETURN total_price;
END;
$$;

alter function calculate_order_total_with_cursor(integer) owner to postgres;

