create view phoneid(工号, 电话号码) as
SELECT "工号",
       "电话号码"
FROM "员工";

alter table phoneid
    owner to postgres;

