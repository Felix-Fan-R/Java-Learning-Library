create function update_order_summary() returns trigger
    language plpgsql
as
$$

BEGIN
	update order_summary SET total_orders=total_orders -1;
	RETURN NEW;
END;

$$;

alter function update_order_summary() owner to postgres;

