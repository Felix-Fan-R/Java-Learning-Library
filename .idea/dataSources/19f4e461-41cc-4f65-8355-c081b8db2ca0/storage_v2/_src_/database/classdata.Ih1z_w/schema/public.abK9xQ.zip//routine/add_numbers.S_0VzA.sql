create function add_numbers(a integer, b integer) returns integer
    language plpgsql
as
$$
begin
	return a+b;
end
$$;

alter function add_numbers(integer, integer) owner to postgres;

