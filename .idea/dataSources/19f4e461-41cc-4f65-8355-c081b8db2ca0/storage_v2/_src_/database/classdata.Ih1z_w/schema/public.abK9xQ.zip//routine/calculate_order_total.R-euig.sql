create function calculate_order_total(order_id_param integer) returns numeric
    language plpgsql
as
$$
DECLARE
	total_price DECIMAL(10,2) := 0;
BEGIN
	SELECT SUM(OI.quantity * p.price) INTO total_price
	FROM order_items oi
	JOIN products p ON oi.product_id=p.product_id
	WHERE oi.order_id = order_id_param;
	return total_price;
END;
$$;

alter function calculate_order_total(integer) owner to postgres;

