create function mul_numbers(x integer, y integer) returns integer
    language plpgsql
as
$$
begin
	return (x+2)*(x+2)+y*x+2*x+y*y*y;
end
$$;

alter function mul_numbers(integer, integer) owner to postgres;

