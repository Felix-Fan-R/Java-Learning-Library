create view idid(工号, "部门ID") as
SELECT "工号",
       "部门ID"
FROM "员工";

alter table idid
    owner to postgres;

