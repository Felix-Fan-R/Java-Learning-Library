create function check_age_before_insert() returns trigger
    language plpgsql
as
$$

BEGIN 
	-- 检查student_id是否在students表中存在  
    IF NOT EXISTS (SELECT 1 FROM students WHERE id = NEW.id) THEN  
        RAISE EXCEPTION 'Student ID % does not exist in students table.', NEW.id;  
        RETURN NULL; -- 终止插入并返回NULL  
    END IF;  

	IF NEW.age < 18 THEN 
	INSERT INTO underage_students (student_id) VALUES (NEW.id); 
	END IF; 
	RETURN NEW; 
END; 

$$;

alter function check_age_before_insert() owner to postgres;

