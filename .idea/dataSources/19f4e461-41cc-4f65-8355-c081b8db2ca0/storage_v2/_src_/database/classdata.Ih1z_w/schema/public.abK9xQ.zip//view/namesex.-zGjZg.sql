create view namesex(工号, 姓名, 性别, "部门ID") as
SELECT "工号",
       "姓名",
       "性别",
       "部门ID"
FROM "员工";

alter table namesex
    owner to postgres;

